# GitHub Pages 部署指南

## 📦 文件说明

- `english-listening-website.zip` - 网站构建产物压缩包
- 解压后包含：
  - `index.html` - 网站入口
  - `assets/` - JS/CSS 资源文件

## 🚀 部署步骤（图文）

### 第一步：创建 GitHub 仓库

1. 登录 [GitHub](https://github.com)
2. 点击右上角 `+` → `New repository`
3. 填写信息：
   - Repository name: `english-listening`（可自定义）
   - Description: `YouTube英语听力学习网站`
   - 选择 `Public`
   - 勾选 `Add a README file`
4. 点击 `Create repository`

### 第二步：上传网站文件

#### 方法 A：网页上传（推荐新手）

1. 进入刚创建的仓库
2. 点击 `Add file` → `Upload files`
3. 解压 `english-listening-website.zip`
4. 把解压后的 **所有文件**（index.html + assets 文件夹）拖拽到上传区域
5. 点击 `Commit changes`

#### 方法 B：命令行上传

```bash
# 解压文件
unzip english-listening-website.zip
cd github-deploy

# 初始化 git
git init
git remote add origin https://github.com/你的用户名/english-listening.git

# 添加文件
git add .
git commit -m "Initial commit"
git push -u origin main
```

### 第三步：开启 GitHub Pages

1. 在仓库页面，点击 `Settings`
2. 左侧菜单找到 `Pages`
3. Source 选择 `Deploy from a branch`
4. Branch 选择 `main` / `master`，文件夹选择 `/ (root)`
5. 点击 `Save`
6. 等待 1-2 分钟，页面会显示访问链接：
   - `https://你的用户名.github.io/english-listening/`

### 第四步：验证部署

1. 打开 `https://你的用户名.github.io/english-listening/`
2. 如果能看到网站内容，说明部署成功！
3. 如果显示空白，检查：
   - 文件是否上传到根目录
   - assets 文件夹是否一起上传

## ⚠️ 常见问题

### Q1: 页面空白怎么办？

**原因**：GitHub Pages 默认使用绝对路径，需要改为相对路径

**解决**：
- 确保 `index.html` 中的资源路径是 `./assets/...` 而不是 `/assets/...`
- 本压缩包已配置为相对路径，直接上传即可

### Q2: 刷新页面 404？

**原因**：单页应用路由问题

**解决**：
- 本项目已使用 HashRouter，不会出现此问题

### Q3: 如何更新网站？

1. 修改代码后重新构建
2. 删除仓库里的旧文件
3. 上传新的构建产物
4. 等待 GitHub Pages 自动更新（约 1-5 分钟）

## 📁 仓库结构示例

```
english-listening/          # 仓库根目录
├── index.html             # 入口文件 ✅ 必须在根目录
├── assets/                # 资源文件夹 ✅ 必须上传
│   ├── index-xxx.js
│   └── index-xxx.css
└── README.md              # 仓库说明
```

## 🔗 重要提示

1. **不要上传 `app/` 源代码文件夹**，只上传构建产物
2. **确保 `index.html` 在根目录**，不是在子文件夹
3. **assets 文件夹必须一起上传**，否则页面会空白
4. 如果仓库名是 `username.github.io`，则访问地址是 `https://username.github.io/`

## 📝 README 模板

建议在仓库添加 README.md：

```markdown
# 英语听力学习网站

基于 YouTube 素材的英语听力学习平台

## 功能
- 变速听力 (0.5x - 2x)
- 智能字幕切换
- 点击查词
- 生词本管理
- 每日打卡

## 访问
https://你的用户名.github.io/english-listening/

## 技术栈
React + TypeScript + Tailwind CSS
```

---

有问题？联系开发者获取帮助
